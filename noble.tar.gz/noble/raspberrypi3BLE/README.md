edit from noble (https://github.com/sandeepmistry/noble) and aws node js sdk (https://github.com/aws/aws-iot-device-sdk.js)
this is to receive BLE data from other sensors and push the data to the AWS using MQTT protocol
