
var noble = require('../index');
const deviceModule = require('..').device;
const cmdLineProcess = require('./lib/cmdline');
console.log('noble');
var sensor;
var datachar = null;	


noble.on('stateChange', function(state) {
  console.log('on -> stateChange: ' + state);

  if (state === 'poweredOn') {
      noble.startScanning("09876543210987654321098765432109", true);
  } else {
    noble.stopScanning();
  }
});

noble.on('scanStart', function() {
  console.log('on -> scanStart');
});

noble.on('scanStop', function() {
  console.log('on -> scanStop');
});

//when discovered device 
noble.on('discover', function(peripheral){
  console.log('on-discover:' + peripheral.address);

  //noble.stopScanning();

  //trying to connect device
  peripheral.connect(function(error){
    console.log('connected to peripheral: ' + peripheral.uuid);
    
    //trying to find the service of certain UUID
    peripheral.discoverServices(['09876543210987654321098765432109'], function(error, services) {
      var temperatureService = services[0];
      console.log('discover temperature service' + services);

      //trying to find characteristics of certain UUID 
      temperatureService.discoverCharacteristics(['12345678901234567890123456789012'], function(error, characteristics) {

        datachar = characteristics[0];	

        datachar.on('read', function(data, isNotification) {
	  var temp = data.toString();
          console.log(temp);
        });	
      });    
    });

  peripheral.on('disconnect', function(error, peripheral){
    console.log('disconnected from peripheral : ' ); 
  });
});

});



var stdin = process.openStdin();
stdin.addListener("data", function(d){
  if(d.toString().trim() == "on"){
    console.log("trying to turn on"); 
    this.changeInterval = setInterval(function(){
      var parameter = new Buffer(2);
      parameter.write("12");
      datachar.write(parameter, false, function(err) {
        if(!err){
		
        }else{
          console.log("error");	 
        }
      });
	
      datachar.read(function(err) {
        if(err){
	  console.log("err");
        }
      });
    }.bind(this), 5000);

  }else if(d.toString().trim() == "off"){
    console.log("trying to turn off");
    if(this.changeInterval){
      clearInterval(this.changeInterval);
      this.changeInterval = null;    
     }  
  }else{
  }
});
